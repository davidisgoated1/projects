from django.apps import AppConfig


class CsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CS_App'
