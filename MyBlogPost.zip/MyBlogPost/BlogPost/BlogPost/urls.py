from django.contrib import admin
from django.urls import path, include
from PostApp import views
from django.contrib.sitemaps.views import sitemap
from PostApp.sitemap import PostSitemap

# Define the sitemap dictionary
sitemaps = {
    'post': PostSitemap,
}

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.post_list, name='post_list'),
    path('post/<slug:slug>/', views.post_detail, name='post_detail'),
    path('create/', views.create_post, name='create_post'),
    path('comment/<int:pk>/', views.comment_view, name='comment_view'),
    path('accounts/', include('django.contrib.auth.urls')),  # Include authentication URLs
    path('sitemap.xml', sitemap, {'sitemaps': sitemaps}, name='django.contrib.sitemaps.views.sitemap'),
    path('PostApp/', include(('PostApp.urls', 'PostApp'), namespace='PostApp')),  # Include PostApp URLs with namespace
]