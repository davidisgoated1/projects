from django import forms
from .models import Comment, Post
from django.contrib.auth.forms import AuthenticationForm

# Custom login form
class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(max_length=254)
    password = forms.CharField(widget=forms.PasswordInput)

# Email form used for sending comments
class EmailForm(forms.Form):
    name = forms.CharField(max_length=50)
    to = forms.EmailField()
    comment = forms.CharField(widget=forms.Textarea, required=False)

# Comment form for posting comments on a post
class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ('name', 'email', 'body')  # Fields defined in the Comment model

# Post form for creating a new blog post
class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'slug', 'body', 'status']  # Adjust fields as per your model