from django.shortcuts import render, get_object_or_404, reverse, redirect
from django.http import HttpResponseRedirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.mail import send_mail
from django.conf import settings
from django.db.models import Count
from .models import Post, Comment
from .forms import EmailForm, CommentForm, PostForm
from django.contrib.auth.models import User

# View for listing posts
def post_list(request):
    all_posts = Post.objects.all()  # Include all posts regardless of status
    paginator = Paginator(all_posts, per_page=10)
    page = request.GET.get('page')

    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)

    return render(request, 'PostApp/homepage.html', {'posts': posts})

# View for post detail
def post_detail(request, slug):
    post = get_object_or_404(Post, slug=slug)
    emailform = EmailForm()
    comments = Comment.objects.filter(post=post, active=True)
    post_tags = post.tags.all()

    similar_posts = Post.published_objects.filter(
        status='published',
        tags__in=post_tags
    ).exclude(pk=post.pk).annotate(tag_count=Count('tags')).order_by('-tag_count')

    if request.method == "POST":
        commentform = CommentForm(request.POST)
        if commentform.is_valid():
            new_comment = commentform.save(commit=False)
            new_comment.post = post
            new_comment.save()
            return HttpResponseRedirect(reverse('PostApp:post_detail', args=[slug]))
    else:
        commentform = CommentForm()

    return render(request, 'PostApp/post_detail.html', {
        'post': post, 'emailform': emailform, 'comments': comments, 'similar_posts': similar_posts, 'commentform': commentform
    })

# View for creating a post
def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            if request.user.is_authenticated:
                post.author = request.user  # Set the author to the logged-in user
            else:
                post.author = User.objects.get(username='default_user')  # Set a default user
            post.status = 'published'  # Set status to 'published'
            post.save()
            return redirect('post_list')
    else:
        form = PostForm()
    return render(request, 'create_post.html', {'form': form})

# View for posting a comment
def comment_view(request, pk):
    post = get_object_or_404(Post, pk=pk)
    commentform = CommentForm()

    if request.method == 'POST':
        commentform = CommentForm(request.POST)
        if commentform.is_valid():
            new_comment = commentform.save(commit=False)
            new_comment.post = post
            new_comment.save()
            return HttpResponseRedirect(reverse('PostApp:post_detail', args=[post.slug]))

    return render(request, 'PostApp/comment.html', {'commentform': commentform})