from django.urls import path
from . import views

app_name = 'PostApp'

urlpatterns = [
    path('', views.post_list, name='post_list'),
    path('post/<slug:slug>/', views.post_detail, name='post_detail'),
    path('create/', views.create_post, name='create_post'),
    path('comment/<int:pk>/', views.comment_view, name='comment_view'),
]